<?php
/**
 * Template: Admin Affiliates List
 */
if (!defined('ABSPATH')) exit;
if (!current_user_can('manage_options')) return;

// Fetch from API
$affiliates_result = DLTPays::fetch_affiliates_from_api();
$payouts_result = DLTPays::fetch_payouts_from_api();

$affiliates = $affiliates_result['affiliates'];
$payouts = $payouts_result['payouts'];

// Pagination
$per_page = 20;
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_page - 1) * $per_page;

// Search
$search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
if ($search) {
    $search_lower = strtolower($search);
    $affiliates = array_filter($affiliates, function($aff) use ($search_lower) {
        return strpos(strtolower($aff['wallet'] ?? ''), $search_lower) !== false ||
               strpos(strtolower($aff['referral_code'] ?? ''), $search_lower) !== false;
    });
}

$total = count($affiliates);
$total_pages = ceil($total / $per_page);
$affiliates = array_slice($affiliates, $offset, $per_page);
?>

<div class="wrap dltpays-admin">
    <h1>
        <?php _e('Affiliates', 'dltpays'); ?>
        <span class="title-count">(<?php echo number_format($total); ?>)</span>
    </h1>
    
    <form method="get" class="search-box" style="margin: 20px 0;">
        <input type="hidden" name="page" value="dltpays-affiliates">
        <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php _e('Search wallet or code...', 'dltpays'); ?>">
        <button type="submit" class="button"><?php _e('Search', 'dltpays'); ?></button>
        <?php if ($search): ?>
            <a href="<?php echo admin_url('admin.php?page=dltpays-affiliates'); ?>" class="button"><?php _e('Clear', 'dltpays'); ?></a>
        <?php endif; ?>
    </form>
    
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th style="width: 60px;"><?php _e('ID', 'dltpays'); ?></th>
                <th><?php _e('Wallet', 'dltpays'); ?></th>
                <th><?php _e('Code', 'dltpays'); ?></th>
                <th><?php _e('Currency', 'dltpays'); ?></th>
                <th><?php _e('Rate', 'dltpays'); ?></th>
                <th><?php _e('Referrals', 'dltpays'); ?></th>
                <th><?php _e('Earned', 'dltpays'); ?></th>
                <th><?php _e('Status', 'dltpays'); ?></th>
                <th><?php _e('Joined', 'dltpays'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($affiliates)): ?>
                <tr>
                    <td colspan="9"><?php _e('No affiliates found.', 'dltpays'); ?></td>
                </tr>
            <?php else: ?>
                <?php foreach ($affiliates as $aff): 
    $wallet = $aff['wallet'] ?? '';
    $code = $aff['referral_code'] ?? '';
    $earned = DLTPays::calculate_actual_earnings($aff['affiliate_id'] ?? '', $payouts);
?>
<tr>
    <td><?php echo esc_html($aff['affiliate_id'] ?? ''); ?></td>
    <td>
        <code title="<?php echo esc_attr($wallet); ?>">
            <?php echo esc_html(substr($wallet, 0, 8)); ?>...<?php echo esc_html(substr($wallet, -4)); ?>
        </code>
        <br>
        <a href="https://livenet.xrpl.org/accounts/<?php echo esc_attr($wallet); ?>" target="_blank" style="font-size: 11px;">
            View on XRPL ↗
        </a>
    </td>
    <td>
        <strong><?php echo esc_html($code); ?></strong>
        <br>
        <button type="button" 
                onclick="navigator.clipboard.writeText('<?php echo esc_url(home_url('?ref=' . $code)); ?>')" 
                style="font-size: 11px; padding: 2px 6px; cursor: pointer;">
            Copy Link
        </button>
    </td>
    <td>RLUSD</td>
    <td>25%</td>
    <td>-</td>
    <td>$<?php echo number_format($earned, 2); ?></td>
    <td>
        <span class="status-badge status-active">Active</span>
    </td>
    <td><?php 
        $date = $aff['created_at'] ?? '';
        if (is_array($date) && isset($date['_seconds'])) {
            echo date('M j, Y', $date['_seconds']);
        } else {
            echo date('M j, Y', strtotime($date));
        }
    ?></td>
</tr>
<?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    
    <?php if ($total_pages > 1): ?>
    <div class="tablenav bottom">
        <div class="tablenav-pages">
            <span class="displaying-num"><?php printf(_n('%s item', '%s items', $total, 'dltpays'), number_format($total)); ?></span>
            <span class="pagination-links">
                <?php if ($current_page > 1): ?>
                    <a href="<?php echo add_query_arg('paged', $current_page - 1); ?>" class="prev-page button">‹</a>
                <?php endif; ?>
                
                <span class="paging-input">
                    <?php echo $current_page; ?> / <?php echo $total_pages; ?>
                </span>
                
                <?php if ($current_page < $total_pages): ?>
                    <a href="<?php echo add_query_arg('paged', $current_page + 1); ?>" class="next-page button">›</a>
                <?php endif; ?>
            </span>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
.status-badge {
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
}
.status-active { background: #d4edda; color: #155724; }
.status-inactive { background: #e2e3e5; color: #383d41; }
.status-suspended { background: #f8d7da; color: #721c24; }
.title-count { font-weight: normal; color: #666; }
</style>
