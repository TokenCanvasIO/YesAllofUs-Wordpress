<?php
/**
 * Template: Admin Dashboard
 * Main DLTPays overview page with stats and recent activity
 */
if (!defined('ABSPATH')) exit;
if (!current_user_can('manage_options')) return;

// Fetch from API (source of truth)
$affiliates_result = DLTPays::fetch_affiliates_from_api();
$payouts_result = DLTPays::fetch_payouts_from_api();

$affiliates = $affiliates_result['affiliates'];
$payouts = $payouts_result['payouts'];

$total_affiliates = count($affiliates);
$total_orders = count($payouts);
$total_paid = 0;
$total_pending = 0;

foreach ($payouts as $payout) {
    foreach ($payout['payments'] ?? [] as $p) {
        if (($p['type'] ?? '') !== 'platform_fee') {
            $amount = floatval($p['amount'] ?? 0);
            if (($payout['status'] ?? '') === 'paid') {
                $total_paid += $amount;
            } else {
                $total_pending += $amount;
            }
        }
    }
}

$recent = array_slice($payouts, 0, 10);
$top_affiliates = $affiliates;

$store_id = get_option('dltpays_store_id');
$has_credentials = !empty($store_id) && !empty(get_option('dltpays_api_secret'));
?>

<div class="wrap dltpays-admin">
    <h1>
        <span style="display: inline-flex; align-items: center; gap: 10px;">
    <img src="<?php echo DLTPAYS_PLUGIN_URL; ?>assets/favicon.svg" width="32" height="32">
    <?php _e('YesAllofUs Dashboard', 'dltpays'); ?>
</span>
    </h1>
    
    <?php if (!$has_credentials): ?>
<div class="dltpays-welcome-card">
    <div class="welcome-content">
        <div class="welcome-icon">
            <img src="<?php echo DLTPAYS_PLUGIN_URL; ?>assets/favicon.svg" width="64" height="64" alt="YesAllofUs" style="border-radius: 12px;">
        </div>
        <h2><?php _e('Welcome to YesAllofUs', 'dltpays'); ?></h2>
        <p class="welcome-tagline"><?php _e('Instant RLUSD affiliate commissions for WooCommerce', 'dltpays'); ?></p>
        
        <div class="welcome-features">
            <div class="feature">
                <span class="feature-icon">⚡</span>
                <span class="feature-text"><?php _e('Instant payouts', 'dltpays'); ?></span>
            </div>
            <div class="feature">
                <span class="feature-icon">💰</span>
                <span class="feature-text"><?php _e('Zero fees', 'dltpays'); ?></span>
            </div>
            <div class="feature">
                <span class="feature-icon">🔗</span>
                <span class="feature-text"><?php _e('5-level MLM', 'dltpays'); ?></span>
            </div>
        </div>
        
        <a href="<?php echo admin_url('admin.php?page=dltpays-settings'); ?>" class="welcome-cta">
            <?php _e('Connect Your Store', 'dltpays'); ?>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </a>
        
        <p class="welcome-subtext">
            <?php _e('Sign in with Google, Apple, or connect your XRPL wallet', 'dltpays'); ?>
        </p>
    </div>
</div>
<?php else: ?>
    
    <!-- Connection Status Bar -->
    <div id="connection-bar" class="dltpays-connection-bar loading">
        <span class="status-icon">⏳</span>
        <span class="status-text"><?php _e('Checking connection...', 'dltpays'); ?></span>
    </div>
    
    <!-- Stats Grid -->
    <div class="dltpays-stats-grid">
        <div class="stat-box">
            <span class="stat-icon">👥</span>
            <span class="stat-number"><?php echo number_format($total_affiliates); ?></span>
            <span class="stat-label"><?php _e('Active Affiliates', 'dltpays'); ?></span>
        </div>
        <div class="stat-box highlight">
            <span class="stat-icon">💰</span>
            <span class="stat-number">$<?php echo number_format($total_paid, 2); ?></span>
            <span class="stat-label"><?php _e('Total Paid (RLUSD)', 'dltpays'); ?></span>
        </div>
        <div class="stat-box">
            <span class="stat-icon">⏳</span>
            <span class="stat-number">$<?php echo number_format($total_pending, 2); ?></span>
            <span class="stat-label"><?php _e('Pending Approval', 'dltpays'); ?></span>
        </div>
        <div class="stat-box">
            <span class="stat-icon">🛒</span>
            <span class="stat-number"><?php echo number_format($total_orders); ?></span>
            <span class="stat-label"><?php _e('Referred Orders', 'dltpays'); ?></span>
        </div>
    </div>
    
    <div class="dltpays-two-column">
        
        <!-- Recent Activity -->
        <div class="dltpays-card">
            <h2><?php _e('Recent Activity', 'dltpays'); ?></h2>
            
            <?php if (empty($recent)): ?>
                <div class="empty-state">
                    <span class="empty-icon">📋</span>
                    <p><?php _e('No commission activity yet.', 'dltpays'); ?></p>
                </div>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Date', 'dltpays'); ?></th>
                            <th><?php _e('Order', 'dltpays'); ?></th>
                            <th><?php _e('Total', 'dltpays'); ?></th>
                            <th><?php _e('Status', 'dltpays'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent as $row): 
                            $order_id = str_replace('wc_', '', $row['order_id'] ?? '');
                            $created = $row['created_at'] ?? '';
                            if (is_array($created) && isset($created['_seconds'])) {
                                $created = date('M j, H:i', $created['_seconds']);
                            } else {
                                $created = date('M j, H:i', strtotime($created));
                            }
                        ?>
                        <tr>
                            <td><?php echo $created; ?></td>
                            <td>#<?php echo esc_html($order_id); ?></td>
                            <td><strong>$<?php echo number_format(floatval($row['order_total'] ?? 0), 2); ?></strong></td>
                            <td>
                                <span class="status-badge status-<?php echo esc_attr($row['status'] ?? 'pending'); ?>">
                                    <?php echo ucfirst($row['status'] ?? 'pending'); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <!-- Top Affiliates -->
        <div class="dltpays-card">
            <h2><?php _e('Top Affiliates', 'dltpays'); ?></h2>
            
            <?php if (empty($top_affiliates)): ?>
                <div class="empty-state">
                    <span class="empty-icon">🏆</span>
                    <p><?php _e('No affiliates registered yet.', 'dltpays'); ?></p>
                </div>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Affiliate', 'dltpays'); ?></th>
                            <th><?php _e('Code', 'dltpays'); ?></th>
                            <th><?php _e('Earned', 'dltpays'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($top_affiliates, 0, 5) as $aff): 
                            $wallet = $aff['wallet'] ?? '';
                            $code = $aff['referral_code'] ?? '';
                            $earned = DLTPays::calculate_actual_earnings($aff['affiliate_id'] ?? '', $payouts);
                        ?>
                        <tr>
                            <td><code style="font-size: 11px;"><?php echo esc_html(substr($wallet, 0, 8)); ?>...</code></td>
                            <td><small style="color: #2563eb;"><?php echo esc_html($code); ?></small></td>
                            <td><strong>$<?php echo number_format($earned, 2); ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            
            <p style="margin-top: 15px;">
                <a href="<?php echo admin_url('admin.php?page=dltpays-affiliates'); ?>" class="button">
                    <?php _e('View All Affiliates →', 'dltpays'); ?>
                </a>
            </p>
        </div>
    
    <!-- Quick Actions -->
    <div class="dltpays-card" style="margin-top: 20px;">
        <h2><?php _e('Quick Actions', 'dltpays'); ?></h2>
        <div class="quick-actions">
    <a href="<?php echo admin_url('admin.php?page=dltpays-settings'); ?>" class="action-button">
        <span class="action-icon">⚙️</span>
        <span class="action-label"><?php _e('Settings', 'dltpays'); ?></span>
    </a>
    <a href="https://yesallofus.com/dashboard" class="action-button" target="_blank">
        <span class="action-icon">📊</span>
        <span class="action-label"><?php _e('Store Dashboard', 'dltpays'); ?></span>
    </a>
    <a href="https://yesallofus.com/docs" class="action-button" target="_blank">
        <span class="action-icon">📚</span>
        <span class="action-label"><?php _e('Documentation', 'dltpays'); ?></span>
    </a>
</div>
    </div>
    
    <?php endif; ?>
</div>

<style>
.dltpays-admin {
    max-width: 1200px;
}

/* Welcome Card - Best in Class */
.dltpays-welcome-card {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #3b82f6 100%);
    border-radius: 16px;
    margin: 20px 0;
    padding: 48px 24px;
    position: relative;
    overflow: hidden;
}
.dltpays-welcome-card::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.3) 0%, transparent 70%);
    pointer-events: none;
}
.welcome-content {
    position: relative;
    z-index: 1;
    text-align: center;
    max-width: 480px;
    margin: 0 auto;
}
.welcome-icon {
    margin-bottom: 20px;
}
.welcome-icon img {
    filter: drop-shadow(0 4px 12px rgba(0,0,0,0.3));
}
.dltpays-welcome-card h2 {
    color: #fff;
    font-size: 32px;
    font-weight: 700;
    margin: 0 0 8px 0;
    letter-spacing: -0.5px;
}
.welcome-tagline {
    color: rgba(255,255,255,0.8);
    font-size: 16px;
    margin: 0 0 28px 0;
}
.welcome-features {
    display: flex;
    justify-content: center;
    gap: 24px;
    margin-bottom: 32px;
    flex-wrap: wrap;
}
.feature {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    padding: 10px 16px;
    border-radius: 24px;
    border: 1px solid rgba(255,255,255,0.15);
}
.feature-icon {
    font-size: 16px;
}
.feature-text {
    color: #fff;
    font-size: 14px;
    font-weight: 500;
}
.welcome-cta {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
    color: #fff !important;
    font-size: 16px;
    font-weight: 600;
    padding: 16px 32px;
    border-radius: 12px;
    text-decoration: none;
    box-shadow: 0 4px 16px rgba(34, 197, 94, 0.4);
    transition: all 0.2s ease;
    white-space: nowrap;
}
.welcome-cta:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 24px rgba(34, 197, 94, 0.5);
    color: #fff !important;
}
.welcome-cta svg {
    transition: transform 0.2s ease;
}
.welcome-cta:hover svg {
    transform: translateX(4px);
}
.welcome-subtext {
    color: rgba(255,255,255,0.6);
    font-size: 13px;
    margin: 20px 0 0 0;
}

@media (max-width: 600px) {
    .dltpays-welcome-card {
        padding: 32px 16px;
        margin: 10px 0;
    }
    .dltpays-welcome-card h2 {
        font-size: 24px;
    }
    .welcome-tagline {
        font-size: 14px;
    }
    .welcome-features {
        gap: 12px;
    }
    .feature {
        padding: 8px 12px;
    }
    .feature-text {
        font-size: 12px;
    }
    .welcome-cta {
    width: auto;
    justify-content: center;
    padding: 14px 24px;
    font-size: 14px;
}
}

/* Connection Bar */
.dltpays-connection-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 16px;
    border-radius: 8px;
    margin: 20px 0;
    font-weight: 500;
}
.dltpays-connection-bar.loading {
    background: #f0f0f0;
    color: #666;
}
.dltpays-connection-bar.connected {
    background: #d4edda;
    color: #155724;
}
.dltpays-connection-bar.error {
    background: #f8d7da;
    color: #721c24;
}
.dltpays-connection-bar.warning {
    background: #fff3cd;
    color: #856404;
}
.dltpays-connection-bar .status-icon {
    font-size: 18px;
}

/* Stats Grid */
.dltpays-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin: 20px 0;
}
.stat-box {
    background: #fff;
    padding: 30px 24px;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    text-align: center;
    transition: transform 0.2s, box-shadow 0.2s;
}
.stat-box:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.stat-box.highlight {
    background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%);
    color: white;
}
.stat-box.highlight .stat-label {
    color: rgba(255,255,255,0.8);
}
.stat-icon {
    display: block;
    font-size: 28px;
    margin-bottom: 15px;
}
.stat-number {
    display: block;
    font-size: 32px;
    font-weight: bold;
    color: #1e3a5f;
    margin-bottom: 8px;
}
.stat-box.highlight .stat-number {
    color: white;
}
.stat-label {
    color: #666;
    font-size: 14px;
}

@media (max-width: 600px) {
    .dltpays-stats-grid {
        grid-template-columns: 1fr 1fr;
        gap: 12px;
    }
    .stat-box {
        padding: 20px 16px;
    }
    .stat-icon {
        font-size: 24px;
        margin-bottom: 10px;
    }
    .stat-number {
        font-size: 24px;
    }
    .stat-label {
        font-size: 12px;
    }
}

/* Two Column Layout */
.dltpays-two-column {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin: 20px 0;
}
@media (max-width: 900px) {
    .dltpays-two-column {
        grid-template-columns: 1fr;
    }
}

/* Cards */
.dltpays-card {
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.dltpays-card h2 {
    margin: 0 0 15px;
    font-size: 18px;
    color: #1e3a5f;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 30px;
    color: #666;
}
.empty-icon {
    font-size: 48px;
    display: block;
    margin-bottom: 10px;
    opacity: 0.5;
}
.empty-state .hint {
    font-size: 13px;
    color: #999;
}

/* Status Badges */
.status-badge {
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    text-decoration: none;
    display: inline-block;
}
.status-paid { background: #d4edda; color: #155724; }
.status-pending { background: #fff3cd; color: #856404; }
.status-queued { background: #e7f3ff; color: #0066cc; }
.status-failed { background: #f8d7da; color: #721c24; }
.status-expired { background: #e9ecef; color: #495057; }

/* Quick Actions */
.quick-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
}
.action-button {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px 30px;
    background: #f8f9fa;
    border-radius: 8px;
    text-decoration: none;
    color: #1e3a5f;
    transition: background 0.2s;
}
.action-button:hover {
    background: #e9ecef;
}
.action-icon {
    font-size: 24px;
    margin-bottom: 8px;
}
.action-label {
    font-weight: 500;
    font-size: 14px;
}

@media (max-width: 600px) {
    .quick-actions {
        gap: 10px;
    }
    .action-button {
        padding: 16px 20px;
        flex: 1;
        min-width: calc(50% - 10px);
    }
    .action-icon {
        font-size: 20px;
    }
    .action-label {
        font-size: 12px;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Check API connection status
    $.ajax({
        url: ajaxurl,
        method: 'POST',
        data: {
            action: 'dltpays_check_connection',
            nonce: '<?php echo wp_create_nonce('dltpays_admin_nonce'); ?>'
        },
        success: function(response) {
            var bar = $('#connection-bar');
            bar.removeClass('loading');
            
            if (response.success) {
                var data = response.data;
                
                if (!data.wallet_address) {
    bar.addClass('warning');
    bar.find('.status-icon').text('⚠️');
    bar.find('.status-text').html(
        '<?php _e('Wallet not connected', 'dltpays'); ?> - ' +
        '<a href="<?php echo admin_url('admin.php?page=dltpays-settings'); ?>"><?php _e('Connect now', 'dltpays'); ?></a>'
    );
} else if (!data.xaman_connected) {
                    bar.find('.status-icon').text('⚠️');
                    bar.find('.status-text').html(
                        '<?php _e('Store not verified', 'dltpays'); ?> - ' +
                        '<a href="<?php echo admin_url('admin.php?page=dltpays-settings'); ?>"><?php _e('Complete setup', 'dltpays'); ?></a>'
                    );
                } else if (!data.xaman_connected) {
    bar.addClass('warning');
    bar.find('.status-icon').text('⚠️');
    bar.find('.status-text').html(
        '<?php _e('Xaman wallet not connected', 'dltpays'); ?> - ' +
        '<a href="<?php echo admin_url('admin.php?page=dltpays-settings'); ?>"><?php _e('Connect now', 'dltpays'); ?></a>'
    );
} else {
    bar.addClass('connected');
    bar.find('.status-icon').text('✓');
    bar.find('.status-text').html(
        '<?php _e('Connected & Ready', 'dltpays'); ?> | ' +
        '<?php _e('Wallet:', 'dltpays'); ?> <code style="font-size: 12px;">' + 
        data.wallet_address.substring(0, 8) + '...' + data.wallet_address.slice(-4) + '</code>'
    );
}
            } else {
                bar.addClass('error');
                bar.find('.status-icon').text('✗');
                bar.find('.status-text').html(
                    '<?php _e('Connection failed', 'dltpays'); ?> - ' +
                    '<a href="<?php echo admin_url('admin.php?page=dltpays-settings'); ?>"><?php _e('Check settings', 'dltpays'); ?></a>'
                );
            }
        },
        error: function() {
            var bar = $('#connection-bar');
            bar.removeClass('loading').addClass('error');
            bar.find('.status-icon').text('✗');
            bar.find('.status-text').text('<?php _e('Connection failed', 'dltpays'); ?>');
        }
    });
});
</script>